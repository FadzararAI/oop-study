public interface Encryptinterface {
	public void encrypt();
	public String decrypt();
}
